#include "raylib.h"

int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "Pong");
    //Audio
    InitAudioDevice();
    Sound Starto = LoadSound("Resources/Start.wav");
    Sound Menuo = LoadSound("Resources/Menu.wav");
    Sound Saliro = LoadSound("Resources/Salir.wav");
    Sound GolpePelota = LoadSound("Resources/GolpePelota.wav");
    Sound BuffBola = LoadSound("Resources/BuffBola.wav");
    Sound Point = LoadSound("Resources/Point.wav");
    Music LobbyMusic = LoadMusicStream("Resources/LobbyMusic.ogg");
    Music MenuMusic = LoadMusicStream("Resources/MenuMusic.ogg");
  //Variables
    enum screen {LOGO,START,LOBBY, GAME, MENU};
    
    int currentScreen = {LOGO};
    
    Rectangle Button1 = {screenWidth/2 - 100, screenHeight/2 - 100 , 200, 50};
    
    Rectangle Button2 = {screenWidth/2 - 100, screenHeight/2  , 200, 50};
    
    Rectangle Button3 = {screenWidth/2 - 100, screenHeight/2 + 100 , 200, 50};
    
    Rectangle LobbyRec = {0, 0  , screenWidth, screenHeight};
    
    Rectangle Player1 = {0, 0, 15,100};
    
    Vector2 Player1Vector = {Player1.x,Player1.y};
       
    Rectangle Player2 = {screenWidth - Player1.width ,  0, 15,100};
    
    Vector2 Player2Vector = {Player2.x,Player2.y};
    
    Rectangle MainMenu = {screenWidth/2 - 60,screenHeight/2 + 100,130,50};
    
    Rectangle Buff = {screenWidth/2+100, screenHeight/2, 35, 35};
    
    int radius = 20;
    
    Vector2 ballPos = {screenWidth/2,screenHeight/2};
    
    bool LogoFade = true;
    
    bool lobbyFade1 = true;
    
    bool buttonSelect1 = false;
    
    bool buttonSelect2 = false;
    
    bool gameFade = true;
    
    bool menuFade = true;
    
    bool startFade = true;
    
    int lobbySize = 40;
    
    bool pause = false;
    
    Vector2 speed = {6 , 6};
    
    int framesCounter = 0;
    
    int leftPoints = 0;
    
    int rightPoints = 0;
    
    bool win = false;
    int secCounter=0;
  
    float alpha = 0.0f;
    //texturas
    Texture2D LobbyTexture = LoadTexture("Resources/FondoLobby.png");
    
    Texture2D LogoTexture = LoadTexture ("Resources/LogoTexture1.png");
    
    Texture2D NameTexture = LoadTexture ("Resources/NameTexture.png");
    
    Texture2D FondoStart = LoadTexture ("Resources/FondoStart.png");
    
    Texture2D ButtonTexture = LoadTexture ("Resources/ButtonText.png");
    
    Texture2D ButtonTextureDark = LoadTexture ("Resources/ButtonEncima.png");
    
    Texture2D FondoJuego = LoadTexture ("Resources/FondoJuego.png");
    
    Texture2D VelocidadText = LoadTexture ("Resources/VelocidadText.png");
    
    Texture2D Player1Text = LoadTexture ("Resources/Player1.png");
    Texture2D Player2Text = LoadTexture ("Resources/Player2.png");
    Texture2D TexturaDeCarga = LoadTexture ("Resources/TexturaDeCarga.png");
    
    

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    //--------------------------------------------------------------------------------------

    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        UpdateMusicStream(LobbyMusic);
        PlayMusicStream(LobbyMusic);
        
        switch(currentScreen)
        {
            case LOGO:
                
                if(LogoFade)
                {
                    alpha += 0.01f;
                    if(alpha >= 1)
                    {
                        LogoFade = false;
                    } 
                }
                else
                {
                    alpha -= 0.01f;
                    if(alpha  <= 0.0f)
                    {
                        currentScreen = START;
                    }
                }     
                
                break;
                
            case START:
            framesCounter++;
          
            if(startFade)
            {
                alpha += 0.01f;

            }
            
            if(!startFade)
            {
                
                if(alpha==1)
                {
                    alpha = 1;
                }
                
                else 
                {
                alpha -= 0.01f;
                }
            }
            
            if(IsKeyPressed(KEY_ENTER))
            {
                currentScreen = LOBBY;
                alpha = 0;
            }
            
                break;
            case LOBBY:
                             
                if(lobbyFade1)
                {
                    alpha += 0.04;
                }
                
                if(!lobbyFade1)
                {
                    alpha -= 0.04;
                }
                
                 //Delimitacion para el fade
                if(alpha >= 1.0f)
                {
                    alpha = 1.0f;
                }
                
                if(alpha <= 0.0f)
                {
                    alpha= 0.0f;
                }
             
               if(buttonSelect1)
               {
                   if(!lobbyFade1)
                    {
                        if(alpha == 0.0f )
                        {
                            currentScreen = GAME;
                            PlaySound(Starto);
                        }
                    }
               }
                   
                if(buttonSelect2)
                {
                    if(!lobbyFade1)
                    {
                        if(alpha == 0.0f )
                        {
                            currentScreen = MENU;
                            PlaySound (Menuo);
                        }
                    }  
                }
                    
             //controlBotones   
                if(CheckCollisionPointRec(GetMousePosition(),Button1))
            {
               
                if(IsMouseButtonReleased(0))
                {
                
                    lobbyFade1 = !lobbyFade1;
                    buttonSelect1 = true;
                    
                
                }
            }
         
            if(CheckCollisionPointRec(GetMousePosition(),Button2))
            {
                if(IsMouseButtonReleased(0))
                {
                
                    lobbyFade1 = !lobbyFade1;
                    buttonSelect2 = true;
                    
                    
                
                }
            }
            if(CheckCollisionPointRec(GetMousePosition(),Button3))
            {
                if(IsMouseButtonReleased(0))
                {
                
                     CloseWindow();
                
                }
            }
            
                break;
               
            case GAME:
            
            framesCounter++;
            secCounter++;
            //pause conytrol
            if(IsKeyPressed(KEY_SPACE))
            {
                pause =! pause;
            }
            
             if(rightPoints == 7)
                {
                    win = true;
                }
                
             if(leftPoints == 7)
                {
                  win = true;
                }               
              
            //cuando no esta pause se activas esto
          if(!pause && !win)
          {
              if(CheckCollisionCircleRec(ballPos,radius,Buff))
              {
                  if(speed.x <=0)
                  {
                      speed.x -=0.5;
                      PlaySound(BuffBola);
                  }
                  if(speed.x >=0)
                  {
                      speed.x += 0.5;
                       PlaySound(BuffBola);
                  }
              }
              
              if(ballPos.x + radius >= screenWidth)
              {
                  ballPos.x = screenWidth/2;
                  ballPos.y = screenHeight/2;
                  leftPoints ++;
                  speed.x = 6;
                  speed.y = 6;
                  PlaySound(Point);
              }
              
          
              if(ballPos.x - radius <= 0)
              {
                  ballPos.x = screenWidth/2;
                  ballPos.y = screenHeight/2;
                  rightPoints ++;
                  speed.x = 6;
                  speed.y = 6;
                  PlaySound(Point);
              }
              
             //Delimitar bolas con barras
         
            if(CheckCollisionCircleRec(ballPos, radius, Player1))
            {
                if(ballPos.x - radius <= Player1.x + Player1.width)
                {
                    speed.x *= -1;
                    PlaySound(GolpePelota);
                }
                
                else if (ballPos.x + radius >= Player1.x)
                {
                    speed.x *= -1;
                    PlaySound(GolpePelota);
                }
            }
            
            if(CheckCollisionCircleRec(ballPos, radius, Player2))
            {
                if(ballPos.x - radius <= Player2.x + Player2.width)
                {
                    speed.x *= -1;
                    PlaySound(GolpePelota);
                }
                
                else if (ballPos.x + radius >= Player2.x)
                {
                    speed.x *= -1;
                    PlaySound(GolpePelota);
                }
            }
          
            { 
            //Velocidad de la bola
                ballPos.x += speed.x;
            
                ballPos.y += speed.y;
                
            //delimitar bola
                if(ballPos.x + radius >= screenWidth || ballPos.x - radius <= 0)
            {
                speed.x *= -1;
            }
            
            if(ballPos.y + radius >= screenHeight || ballPos.y - radius <= 0)
            {
                speed.y *= -1;
            }
            
             //fade
                if(gameFade)
                {
                    alpha += 0.04;
                }
                if(!gameFade)
                {
                    alpha -= 0.04;
                }
                
                
                if(alpha >= 1.0f)
                {
                    alpha = 1.0f;
                }
                
                
                if(alpha <= 0.0f)
                {
                    alpha= 0.0f;
                }
                 //controles player1
                 
                if(IsKeyDown(KEY_S))
                    
            {
                if(Player1.y + Player1.height == screenHeight)
                {
                    Player1.y = screenHeight - Player1.height;
                }
                else
                {
                    Player1.y +=7;
                    Player1Vector.y +=7;
                }
                
                
            }
            
            if(IsKeyDown(KEY_W))
            {
                if(Player1.y==0)
                {
                    Player1.y = 0 ;
                }
                else
                {
                    Player1.y -=7;
                    Player1Vector.y -=7;
                }
                
            }
                 
            }
            //controlesplayer2(IA)
            
            if(Player2.y <= 0) Player2.y = 0;
            if(Player2Vector.y <= 0) Player2Vector.y = 0;
            if(Player2.y >= screenHeight - Player2.height) Player2.y = screenHeight - Player2.height;
            if(Player2Vector.y >= screenHeight - Player2.height) Player2Vector.y = screenHeight - Player2.height;
            
            if(ballPos.x >= screenWidth/2)
                {
                   if (speed.x >= 0) 
                {
            
                if(ballPos.y > Player2.y)
                {
                    Player2.y += 7;
                    Player2Vector.y +=7;
                    
                }
                else if ( ballPos.y < Player2.y)
                {
                    Player2.y -= 7;
                    Player2Vector.y -=7;
                }
            
        }
           
            }
          }
           
                 break;
      
            case MENU:
            
            //fade
            if(menuFade)
                {
                    alpha += 0.04;
                }
                if(!gameFade)
                {
                    alpha -= 0.04;
                }
                
                
                if(alpha >= 1.0f)
                {
                    alpha = 1.0f;
                }
                
                
                if(alpha <= 0.0f)
                {
                    alpha= 0.0f;
                }
            
               break;
                
        }
  
        // Update
        //----------------------------------------------------------------------------------
        // TODO: Update your variables here
        //----------------------------------------------------------------------------------

        // Draw
        //----------------------------------------------------------------------------------
        BeginDrawing();
        

            ClearBackground(RAYWHITE);
            
            
           
             switch(currentScreen)
             {
                 case LOGO: 
                    //DibujarLogo
                    DrawTexture(LogoTexture,0,0,Fade(WHITE,alpha));
                    
                    break;
                    
                        
                case START:
                
                    DrawTexture(NameTexture,0,0,Fade(WHITE, alpha));
                    
                    if((framesCounter/20)%2) 
                    {
                        DrawText("Press Enter To Start", 285, 300,20, Fade (RED,alpha));
                    }
                
                    
                    break;
                
                 
                case LOBBY:
                    
                //Dibujar Botones
                
                DrawTextureRec (FondoStart, LobbyRec ,(Vector2){0,0} , Fade(WHITE,alpha));
                
                
                
                if(CheckCollisionPointRec(GetMousePosition(),Button1))
                {
                    DrawTexture(ButtonTextureDark,screenWidth/2 - 100, screenHeight/2 - 100,Fade(WHITE,alpha));
                }else
                {
                    DrawTexture(ButtonTexture,screenWidth/2 - 100, screenHeight/2 - 100,Fade(WHITE,alpha));
                }
                
                if(CheckCollisionPointRec(GetMousePosition(),Button2))
                {
                    DrawTexture(ButtonTextureDark,screenWidth/2 - 100, screenHeight/2 ,Fade(WHITE,alpha));
                }else
                {
                    DrawTexture(ButtonTexture,screenWidth/2 - 100, screenHeight/2 ,Fade(WHITE,alpha));
                }
                
                if(CheckCollisionPointRec(GetMousePosition(),Button3))
                {
                    DrawTexture(ButtonTextureDark,screenWidth/2 - 100, screenHeight/2 + 100 ,Fade(WHITE,alpha));
                }else
                {
                    DrawTexture(ButtonTexture,screenWidth/2 - 100, screenHeight/2 + 100  ,Fade(WHITE,alpha));
                }

                //dibujar texto
               
                DrawText("JUGAR",Button1.x + 35 ,Button1.y + 5  , lobbySize,Fade (BLACK,alpha));
                
                DrawText("MENU",Button2.x + 40  ,Button2.y + 5  , lobbySize,Fade(BLACK,alpha));
                
                DrawText("SALIR",Button3.x + 35 ,Button3.y + 5 , lobbySize,Fade (BLACK,alpha));
                
                break;
              
                break ;
                
                case GAME:
                
                DrawTexture(FondoJuego,0,0,WHITE);
                //dibujar texto mientras esta pause
                if(pause)
                {
                    DrawText("PAUSE",screenWidth/2 - 70,0,40,BLACK);
                }
                //dibujar componentes juego
                DrawRectangleRec(Player1,Fade(RED, alpha));
                DrawTextureV(Player1Text, Player1Vector ,WHITE);
                
                
                DrawRectangleRec(Player2,Fade(BLUE, alpha));
                DrawTextureV(Player2Text, Player2Vector ,WHITE);
                
                DrawCircle(ballPos.x, ballPos.y, radius, Fade(BLACK, alpha));
                
                //Puntuacion
                DrawText(FormatText("Points: %01i", leftPoints), 100, 20, 35, Fade(RED, alpha));
                
                DrawText(FormatText("Points: %01i", rightPoints), 600, 20, 35, Fade(BLUE, alpha));
                
                //sistema de victtoria
                if(rightPoints == 7)
                {
                    DrawText("Left Player WINS!", 170, screenHeight/2 - 40,50,RED);
                    if((framesCounter/20)%2)
                        {
                        DrawText("Press Enter To Return ",screenWidth/2 - 150,screenHeight/2 + 100,25,BLACK);
                         }
                    
                   if(IsKeyPressed(KEY_ENTER))
                    {
                        currentScreen = LOBBY;
                            leftPoints = 0;
                            buttonSelect1=false;
                            lobbyFade1 = true;
                            win = false;
                    }
                }
                if(leftPoints == 7)
                {
                    DrawText("Right Player WINS!", 170, screenHeight/2 - 40,50,BLUE);
                     if((framesCounter/20)%2)
                         {
                        DrawText("Press Enter To Return ",screenWidth/2 - 150,screenHeight/2 + 100,25,BLACK);
                        }
                     
                     
                    if(IsKeyPressed(KEY_ENTER))
                    {
                        currentScreen = LOBBY;
                            leftPoints = 0;
                            buttonSelect1=false;
                            lobbyFade1 = true;
                            win=false;
                    }
                } 
              
           DrawRectangleRec(Buff,GREEN);
           DrawTexture (VelocidadText,screenWidth/2+100, screenHeight/2,WHITE);
           if(secCounter <= 60)
             {
                 DrawTexture (TexturaDeCarga,0,0,WHITE);
                  if((framesCounter/20)%2) 
                  {
                       DrawText("CARGANDO...",300,220,30,WHITE);
                  }
                
             }
             
                break; 
                
                case MENU:
                
                DrawRectangleRec(Button1,Fade(RED,alpha));
           
           
                break;  
             }
         
        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}